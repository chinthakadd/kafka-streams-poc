UI:

Mongo Express UI: http://localhost:8091
Schema Registry UI: http://localhost:8094
Kafka UI: http://localhost:8095

Components:

MySQL-Port: 3306
Kafka-Port: 29092
Mongo-Port: 27017
Zookeeper-Port: 2181
Kafka-Connect: 8092
Schema-Registry: 8093
